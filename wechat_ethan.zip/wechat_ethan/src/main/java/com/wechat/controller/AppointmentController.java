package com.wechat.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wechat.model.Appointment;
import com.wechat.service.IAppointmentService;

@Controller
@RequestMapping("/appointment.do")
public class AppointmentController {
	@Resource IAppointmentService appointmentService; 
	
	@RequestMapping(value="/addAppointment",method=RequestMethod.GET,produces = "text/json;charset=UTF-8")
	public @ResponseBody String addAppointment(HttpServletRequest request) {
		String taocan = request.getParameter("taocan");
		String userName = request.getParameter("username");
		String telephone = request.getParameter("telephone");
		String date = request.getParameter("date");
		String time = request.getParameter("time");
		String fromDes = request.getParameter("fromDes");
		String toDes = request.getParameter("toDes");
		String note = request.getParameter("note");
		
		System.out.println(taocan + userName + telephone + date + time +fromDes + toDes + note);
		
		Appointment appointment = new Appointment();
		appointment.setTaocan(taocan);
		appointment.setUserName(userName);
		appointment.setTelephone(telephone);
		appointment.setDate(date);
		appointment.setTime(time);
		appointment.setFromDes(fromDes);
		appointment.setToDes(toDes);
		appointment.setNote(note);
		
		appointmentService.addAppointment(appointment);
		
		return "成功";
	}
}
