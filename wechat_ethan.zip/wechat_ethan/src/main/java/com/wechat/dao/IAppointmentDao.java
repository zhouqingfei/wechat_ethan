package com.wechat.dao;

import com.wechat.model.Appointment;

public interface IAppointmentDao {
	int insert(Appointment record);
}
