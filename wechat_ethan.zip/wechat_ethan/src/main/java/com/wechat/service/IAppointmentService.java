package com.wechat.service;

import org.springframework.stereotype.Service;

import com.wechat.model.Appointment;

@Service("appointmentService")
public interface IAppointmentService {
	public void addAppointment(Appointment appointment);
}
